import botocore
import json
import boto3
import os

DESTINATION_REGION = os.environ['DESTINATION_REGION']

def lambda_handler(event, context):
     print(event)
     
     sourceRegion = event['region']

     rds = boto3.client('rds', region_name = DESTINATION_REGION)
     sourceSnapshotARN = event['detail']['SourceArn']

     #build a new snapshot name
     sourceSnapshotIdentifer = event['detail']['SourceIdentifier']

    # colon is present in automated snaphosts which needs to be removed.
     sourceSnapshotIdentifer = sourceSnapshotIdentifer.replace(':','-')
            
     targetSnapshotIdentifer = "{0}-copy".format(sourceSnapshotIdentifer)
    
     print(sourceSnapshotIdentifer)
     #Execute copy
     try:
         copy = rds.copy_db_cluster_snapshot(
             SourceDBClusterSnapshotIdentifier = sourceSnapshotARN,
             TargetDBClusterSnapshotIdentifier = targetSnapshotIdentifer,
             SourceRegion = sourceRegion,
             KmsKeyId = 'alias/aws/rds' )
         print("Started Copy of Snapshot {0} in {2} to {1} in {3} ".format(
             sourceSnapshotIdentifer,
             targetSnapshotIdentifer,
             sourceRegion,DESTINATION_REGION)
         )
     except botocore.exceptions.ClientError as ex:
         if ex.response['Error']['Code'] == 'DBSnapshotAlreadyExists':
             print("Snapshot {0} already exist".format(targetSnapshotIdentifer))
         else:
             print("ERROR: {0}".format(ex.response['Error']['Code']))

     return {
         'statusCode': 200,
         'body': json.dumps('Opearation Complete')
     }