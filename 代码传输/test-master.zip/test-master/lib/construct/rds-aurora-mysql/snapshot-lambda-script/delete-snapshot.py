import boto3
from botocore.client import ClientError
from datetime import datetime, timedelta, tzinfo
import os

RDS_CLUSTER_NAME = os.environ['RDS_CLUSTER_NAME']
DELETE_DAYS = os.environ['DELETE_DAYS']
TARGET_REGION = os.environ['TARGET_REGION']

rds = boto3.client('rds', region_name=TARGET_REGION)

def delete_snapshots(prefix, days):
    snapshots = rds.describe_db_cluster_snapshots()
    now = datetime.utcnow().replace(tzinfo=None)
    for snapshot in snapshots['DBClusterSnapshots']:
        if not 'SnapshotCreateTime' in snapshot:
            continue
        
        # スナップショット作成時刻から経過時間を測定
        delta = now - snapshot['SnapshotCreateTime'].replace(tzinfo=None)
        if snapshot['DBClusterSnapshotIdentifier'].startswith(prefix) and delta.days >= days:
            print(snapshot['DBClusterSnapshotIdentifier'])
            rds.delete_db_cluster_snapshot(DBClusterSnapshotIdentifier=snapshot['DBClusterSnapshotIdentifier'])
            print('%d日前のスナップショットを削除しました' % delta.days)
            
def lambda_handler(event, context):
    delete_days = int(DELETE_DAYS)
    snapshot_prefix = "rds-{0}".format(RDS_CLUSTER_NAME)
    delete_snapshots(snapshot_prefix, delete_days)
            