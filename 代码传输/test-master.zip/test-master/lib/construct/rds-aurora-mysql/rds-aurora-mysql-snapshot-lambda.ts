import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_events as events } from 'aws-cdk-lib';
import { aws_iam as iam } from 'aws-cdk-lib';
import { aws_events_targets as eventsTargets } from 'aws-cdk-lib';
import { aws_lambda as lambda } from 'aws-cdk-lib';
import * as path from 'path';

/**
 * RdsAuroraMysqlSnapshotLambdaConstruct のプロパティ
 */
type RdsAuroraMysqlSnapshotLambdaConstructProps = {

    /**
     * スナップショットコピー対象のRDSクラスターの識別子
     */
    clusterIdentifier: string;
    copySnapshotProps: {
        /**
         * ファンクション名
         */
        functionName?: string,
        /**
         * イベントブリッジ名
         */
        eventsName?: string,
        /**
         * コピー先のリージョン
         */
        destinationRegion: string,
    };

    deleteSnapshotProps: {
        /**
         * ファンクション名
         */
        functionName?: string,
        eventsName?: string,
        /**
         * スナップショットを削除する日数
         */
        deleteDays?: number,
        /**
         * スケジュールする時間
         * cron UTCで設定 
         * @default 'cron(0 15 * * ? *)'
         */
        scheduleCronExpression?: string;
    };
}

/**
 * RDS  Cluster クロスリージョンスナップショットファンクション作成
 */
export class RdsAuroraMysqlSnapshotLambdaConstruct extends Construct {
    /**
     * RDS コピースナップショットファンクション
     */
    readonly copySnapshotFunc: lambda.IFunction;
    /**
     * RDS スナップショット削除ファンクション
     */
    readonly deleteSnapshotFunc: lambda.IFunction;

    constructor(scope: Construct, id: string, props: RdsAuroraMysqlSnapshotLambdaConstructProps) {
        super(scope, id);

        /** RDS コピースナップショットファンクション */
        this.copySnapshotFunc = new lambda.Function(this, 'CopySnapshotFunc', {
            functionName: props.copySnapshotProps.functionName,
            code: lambda.Code.fromAsset(path.join(__dirname, './snapshot-lambda-script')),
            handler: 'copy-snapshot.lambda_handler',
            runtime: cdk.aws_lambda.Runtime.PYTHON_3_9,
            description: 'Copy RDS snapshots cross-region.',
            memorySize: 128,
            timeout: cdk.Duration.minutes(15),
            environment: {
                'DESTINATION_REGION': props.copySnapshotProps.destinationRegion
            },
        });
        if (props.copySnapshotProps.functionName) {
            cdk.Tags.of(this.copySnapshotFunc).add('Name', props.copySnapshotProps.functionName);
        }

        this.copySnapshotFunc.addToRolePolicy(new iam.PolicyStatement({
            sid: 'AllowCopyRdsSnapshot',
            effect: iam.Effect.ALLOW,
            resources: ['*'],
            actions: [
                'rds:DescribeDBClusterSnapshotAttributes',
                'rds:AddTagsToResource',
                'rds:DescribeDBSnapshots',
                'rds:CopyDBSnapshot',
                'rds:CopyDBClusterSnapshot',
                'rds:DescribeDBClusterSnapshots',
                'rds:DescribeDBSnapshotAttributes',
            ],
        }));
        const copySnapshotEvents = new events.Rule(this, 'EventOnCreateRdsBackup', {
            description: 'Event on create RDS backup.',
            ruleName: props.copySnapshotProps.eventsName,
            eventPattern: {
                source: ['aws.rds'],
                detailType: [
                    'RDS DB Cluster Snapshot Event'
                ],
                detail: {
                    EventID: ['RDS-EVENT-0075', 'RDS-EVENT-0169'],
                    SourceIdentifier: [{ prefix: `rds:${props.clusterIdentifier}` }],
                },
            },
            targets: [new eventsTargets.LambdaFunction(this.copySnapshotFunc, { retryAttempts: 3 })],
        });
        if (props.copySnapshotProps.eventsName) {
            cdk.Tags.of(copySnapshotEvents).add('Name', props.copySnapshotProps.eventsName);
        }

        /** RDS スナップショット削除ファンクション */
        this.deleteSnapshotFunc = new lambda.Function(this, 'DeleteSnapshotFunc', {
            functionName: props.deleteSnapshotProps.functionName,
            code: lambda.Code.fromAsset(path.join(__dirname, './snapshot-lambda-script')),
            handler: 'delete-snapshot.lambda_handler',
            runtime: cdk.aws_lambda.Runtime.PYTHON_3_9,
            description: 'Delete RDS snapshots.',
            memorySize: 128,
            timeout: cdk.Duration.minutes(15),
            environment: {
                'RDS_CLUSTER_NAME': props.clusterIdentifier,
                'DELETE_DAYS': '' + props.deleteSnapshotProps.deleteDays || '7',
                'TARGET_REGION': props.copySnapshotProps.destinationRegion
            },
        });
        if (props.deleteSnapshotProps.functionName) {
            cdk.Tags.of(this.copySnapshotFunc).add('Name', props.deleteSnapshotProps.functionName);
        }
        this.deleteSnapshotFunc.addToRolePolicy(new iam.PolicyStatement({
            sid: 'AllowDeleteRdsSnapshot',
            effect: iam.Effect.ALLOW,
            resources: ['*'],
            actions: [
                'rds:DescribeDBClusterSnapshotAttributes',
                'rds:AddTagsToResource',
                'rds:DeleteDBClusterSnapshot',
                'rds:DescribeDBSnapshots',
                'rds:DescribeDBClusterSnapshots',
                'rds:DeleteDBSnapshot',
                'rds:DescribeDBSnapshotAttributes',
            ],
        }));
        const deleteSnapshotEvents = new events.Rule(this, 'DeleteRdsSnapshotsRule', {
            description: 'Delete RDS snapshots rule.',
            ruleName: props.deleteSnapshotProps.eventsName,
            schedule: events.Schedule.expression(props.deleteSnapshotProps.scheduleCronExpression || 'cron(0 15 * * ? *)'),
            targets: [new eventsTargets.LambdaFunction(this.deleteSnapshotFunc, { retryAttempts: 3 })],
        });
        if (props.deleteSnapshotProps.eventsName) {
            cdk.Tags.of(deleteSnapshotEvents).add('Name', props.deleteSnapshotProps.eventsName);
        }
    }
}
