import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_rds as rds } from 'aws-cdk-lib';
import { aws_cloudwatch as cw } from 'aws-cdk-lib';
import { aws_sns as sns } from 'aws-cdk-lib';
import { aws_ec2 as ec2 } from 'aws-cdk-lib';
import { aws_secretsmanager as secretManager } from 'aws-cdk-lib';
import { aws_cloudwatch_actions as cw_actions } from 'aws-cdk-lib';
import { RdsAuroraMysqlSnapshotLambdaConstruct } from './rds-aurora-mysql-snapshot-lambda';
import { aws_logs as logs } from 'aws-cdk-lib';

/**
 * RdsAuroraMysqlConstruct のプロパティ
 */
type RdsAuroraMysqlConstructProps = {
    vpc: ec2.IVpc;
    privateSubnets: ec2.ISubnet[];
    /**
     * RDSインスタンスタイプ
     * @default t3.medium
     */
    rdsInstaceTypeStr?: string;
    /**
     * RDSインスタンス数 (2以上指定でレプリカ作成)
     * @default 1
     */
    rdsInstances?: number,
    /**
     * バックアップ期間
     * @default no backup
     */
    backupDays?: number
    /**
     * RDSシークレットマネージャ名
     */
    rdsSecretName?: string
    /**
     * RDSセキュリティグループ名
     */
    rdsSecurityGroupName?: string
    /**
     * RDSサブネットグループ名
     */
    rdsSubnetGroupName?: string
    /**
     * RDSパラメータグループ名
     */
    rdsParameterGroupName?: string
    /**
     * RDSクラスター名
     */
    rdsClusterName?: string
    /**
     * RDSインスタンス名プレフィックス
     */
    rdsInstanceIdentifierBase?: string
    /** 
     * CDK Destroy 自動削除
     * @default false
     **/
    cdkAutoRemove?: boolean;
}
/**
 * CreateSnapshotFunctions プロパティ
 */
type CreateSnapshotFunctionsProps = {

    copySnapshotProps: {
        functionName?: string,
        eventsName?: string,
        destinationRegion: string,
    };

    deleteSnapshotProps: {
        functionName?: string,
        eventsName?: string,
        /**
         * スナップショットを削除する日数
         */
        deleteDays?: number,
        /**
         * スケジュールする時間
         * cron UTCで設定 
         * @default 'cron(0 15 * * ? *)'
         */
        scheduleCronExpression?: string;
    };
}

/**
 * RDS Aurora MySQL Cluster 作成
 */
export class RdsAuroraMysqlConstruct extends Construct {
    /**
     * RDS シークレット
     */
    readonly rdsSecret: secretManager.Secret;
    /**
     * RDS クラスター
     */
    readonly rdsCluster: rds.DatabaseCluster;
    /**
     * インスタンスタイプ
     * @example t3.medium
     */
    readonly rdsInstaceTypeStr: string;
    /**
     * ロググループリスト
     */
    readonly rdsLogs: { [logType: string]: logs.ILogGroup };

    constructor(scope: Construct, id: string, props: RdsAuroraMysqlConstructProps) {
        super(scope, id);
        //定数
        const dbPort = 3306;
        this.rdsInstaceTypeStr = props.rdsInstaceTypeStr || 't3.medium';
        const cloudwatchLogsExportsList = ['error', 'general', 'slowquery', 'audit'];

        // SecretManager
        this.rdsSecret = new secretManager.Secret(this, 'dbSecret', {
            secretName: props.rdsSecretName,
            description: 'RDS AuroraMysql user password.',
            generateSecretString: {
                secretStringTemplate: JSON.stringify({ username: 'auroramysql' }),
                generateStringKey: 'password',
                excludeCharacters: "\"%+~`#$&()|[]{}:;<>?!'/@)*-\\",
            },
        });
        if (props.rdsSecretName) {
            cdk.Tags.of(this.rdsSecret).add('Name', props.rdsSecretName);
        }

        // RDS SecurityGroup
        const sg = new ec2.SecurityGroup(this, 'sg-rds-aurora', {
            vpc: props.vpc,
            securityGroupName: props.rdsSecurityGroupName,
            allowAllOutbound: true,
        });
        props.privateSubnets.forEach(v_ => {
            sg.addIngressRule(ec2.Peer.ipv4(v_.ipv4CidrBlock), ec2.Port.tcp(dbPort), 'allow MySql port access.',);
        });
        if (props.rdsSecurityGroupName) {
            cdk.Tags.of(sg).add('Name', props.rdsSecurityGroupName);
        }

        // RDS SubnetGroup 
        const subnetGroup = new rds.SubnetGroup(this, 'rds-subnetgrp', {
            vpc: props.vpc,
            description: props.rdsSubnetGroupName || '',
            subnetGroupName: props.rdsSubnetGroupName,
            vpcSubnets: { subnets: props.privateSubnets }
        });
        if (props.rdsSubnetGroupName) {
            cdk.Tags.of(subnetGroup).add('Name', props.rdsSubnetGroupName);
        }

        // RDS ParameterGroup
        const parameterGroup = new rds.ParameterGroup(this, 'rds-parameterGrp', {
            description: props.rdsParameterGroupName,
            engine: {
                engineType: 'aurora-mysql',
                parameterGroupFamily: 'aurora-mysql8.0'
            },
            parameters: {
                time_zone: 'Asia/Tokyo',
                character_set_client: 'utf8mb4',
                character_set_connection: 'utf8mb4',
                character_set_database: 'utf8mb4',
                character_set_results: 'utf8mb4',
                character_set_server: 'utf8mb4',
                collation_connection: 'utf8mb4_bin',
                collation_server: 'utf8mb4_bin',
                server_audit_logging: '1',
                server_audit_logs_upload: '1',
                server_audit_events: 'CONNECT,QUERY,TABLE',
                general_log: '1',
                slow_query_log: '1'
            }
        });
        if (props.rdsParameterGroupName) {
            cdk.Tags.of(parameterGroup).add('Name', props.rdsParameterGroupName);
        }

        // RDS Aurora MySQL Cluster
        this.rdsCluster = new rds.DatabaseCluster(this, 'rds-aurora', {
            engine: rds.DatabaseClusterEngine.auroraMysql({
                version: rds.AuroraMysqlEngineVersion.VER_3_02_1,
            }),
            clusterIdentifier: props.rdsClusterName,
            credentials: rds.Credentials.fromSecret(this.rdsSecret),
            port: dbPort,
            instances: props.rdsInstances || 1,
            defaultDatabaseName: 'rsltproc',
            instanceIdentifierBase: props.rdsInstanceIdentifierBase,
            storageEncrypted: true,
            cloudwatchLogsRetention: cdk.aws_logs.RetentionDays.ONE_YEAR,
            cloudwatchLogsExports: cloudwatchLogsExportsList,
            removalPolicy: props.cdkAutoRemove ? cdk.RemovalPolicy.DESTROY : cdk.RemovalPolicy.RETAIN,
            monitoringInterval: cdk.Duration.minutes(1),
            backup: props.backupDays ? {
                retention: cdk.Duration.days(props.backupDays),
                preferredWindow: '16:00-16:30'
            } : undefined,
            copyTagsToSnapshot: true,
            preferredMaintenanceWindow: 'Sat:15:00-Sat:15:30',
            subnetGroup: subnetGroup,
            parameterGroup: parameterGroup,
            deletionProtection: !props.cdkAutoRemove,
            instanceProps: {
                instanceType: new ec2.InstanceType(this.rdsInstaceTypeStr || 't3.medium'),
                vpc: props.vpc,
                securityGroups: [sg],
                vpcSubnets: {
                    subnets: props.privateSubnets,
                },
                allowMajorVersionUpgrade: false,
                autoMinorVersionUpgrade: true,
            },
        });
        if (props.rdsClusterName) {
            cdk.Tags.of(this.rdsCluster).add('Name', props.rdsClusterName, {
                includeResourceTypes: ['AWS::RDS::DBCluster']
            });
        }
        // RDSロググループコンストラクト生成
        this.rdsLogs = {};
        cloudwatchLogsExportsList.forEach(v_ => {
            const logs_ = logs.LogGroup.fromLogGroupName(this, `${v_}Log`, `/aws/rds/cluster/${this.rdsCluster.clusterIdentifier}/${v_}`);
            this.rdsLogs[v_] = logs_;
            logs_.node.addDependency(this.rdsCluster);
        });

    }

    /**
     * CPUアラームを追加
     * @param id
     * @param alarmTopic 通知するSNSトピック
     * @param thresholdRate CPU使用率のアラート閾値
     * @param alarmName アラーム名
     */
    addCpuArarm(id: string, alarmTopic: sns.ITopic, thresholdRate = 0.8, alarmName?: string) {
        const alarm = this.rdsCluster
            .metricCPUUtilization({
                period: cdk.Duration.minutes(5),
                statistic: cw.Statistic.AVERAGE,
            })
            .createAlarm(this, id, {
                evaluationPeriods: 5,
                datapointsToAlarm: 1,
                threshold: thresholdRate * 100,
                comparisonOperator: cw.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
                actionsEnabled: true,
                treatMissingData: cw.TreatMissingData.BREACHING,
                alarmName,
            });
        if (alarmName) {
            cdk.Tags.of(alarm).add('Name', alarmName);
        }
        alarm.addAlarmAction(new cw_actions.SnsAction(alarmTopic));
    }
    /**
     * 空きメモリ使用率アラームを追加
     * @param id
     * @param alarmTopic 通知するSNSトピック
     * @param memorySize メモリサイズ
     * @param thresholdRate 空きメモリ使用率のアラート閾値
     * @param alarmName アラーム名
     */
    addMemoryArarm(id: string, alarmTopic: sns.ITopic, memorySize: number, thresholdRate = 0.2, alarmName?: string) {
        const alarm = this.rdsCluster
            .metricFreeableMemory({
                period: cdk.Duration.minutes(5),
                statistic: cw.Statistic.AVERAGE,
            })
            .createAlarm(this, id, {
                evaluationPeriods: 5,
                datapointsToAlarm: 1,
                threshold: memorySize * thresholdRate,
                comparisonOperator: cw.ComparisonOperator.LESS_THAN_OR_EQUAL_TO_THRESHOLD,
                actionsEnabled: true,
                treatMissingData: cw.TreatMissingData.BREACHING,
                alarmName,
            });
        if (alarmName) {
            cdk.Tags.of(alarm).add('Name', alarmName);
        }
        alarm.addAlarmAction(new cw_actions.SnsAction(alarmTopic));
    }

    /**
     * @param id
     * @param alarmTopic 通知するSNSトピック
     * @param thresholdByte 空きストレージサイズの閾値 (バイト)
     * @param alarmName アラーム名
     */
    addStorageArarm(id: string, alarmTopic: sns.ITopic, thresholdByte = 1000000000, alarmName?: string) {
        const alarm = this.rdsCluster
            .metricFreeableMemory({
                period: cdk.Duration.minutes(5),
                statistic: cw.Statistic.AVERAGE,
            })
            .createAlarm(this, id, {
                evaluationPeriods: 5,
                datapointsToAlarm: 1,
                threshold: thresholdByte,
                comparisonOperator: cw.ComparisonOperator.LESS_THAN_OR_EQUAL_TO_THRESHOLD,
                actionsEnabled: true,
                treatMissingData: cw.TreatMissingData.BREACHING,
                alarmName,
            });
        if (alarmName) {
            cdk.Tags.of(alarm).add('Name', alarmName);
        }
        alarm.addAlarmAction(new cw_actions.SnsAction(alarmTopic));
    }

    createSnapshotFunctions(id: string, props: CreateSnapshotFunctionsProps): RdsAuroraMysqlSnapshotLambdaConstruct {
        return new RdsAuroraMysqlSnapshotLambdaConstruct(this, id, {
            clusterIdentifier: this.rdsCluster.clusterIdentifier,
            copySnapshotProps: props.copySnapshotProps,
            deleteSnapshotProps: props.deleteSnapshotProps
        });
    }
}
