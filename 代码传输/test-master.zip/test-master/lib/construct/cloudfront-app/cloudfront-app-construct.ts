import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_s3 as s3 } from 'aws-cdk-lib';
import { aws_cloudfront as cloudfront } from 'aws-cdk-lib';
import { aws_certificatemanager as acm } from 'aws-cdk-lib';
import { IBucket } from 'aws-cdk-lib/aws-s3';
import { aws_iam as iam } from 'aws-cdk-lib';

/**
 * CloudfrontAppConstruct プロパティ
 */
type CloudfrontAppConstructProps = {
    /**
     * CloudFront WAF ID
     */
    webAclId?: string;
    /**
     * CloudfrontにホストするACMのArn（北部バージニアにて作成すること）
     */
    acmArn: string;
    /**
     * ドメインネーム
     */
    domainName: string;
    /**
     * フロントエンドバケット
     */
    frontBucket: s3.IBucket
    /**
     * アクセスログバケット
     */
    accessLogBucket?: IBucket;
    /**
     * エラーコンフィグ
     */
    errorConfigurations?: cloudfront.CfnDistribution.CustomErrorResponseProperty[]
    /**
     * バックエンドオリジン設定
     * @default バックエンドオリジンは作成しない
     */
    backendOriginConfig?: {
        originHeader?: { [key: string]: string; }
        /**
         * パスパターン
         * @default '/api/*'
         */
        pathPattern?: string,
        /**
         * フォワードヘッダーリスト
         * @default ["Authorization"]
         */
        forwardedHeaders?: string[]
        /**
         * バックエンド ドメイン名
         */
        domainName: string;
    },
    /**
     * クラウドフロント Distribution Nameタグ
     */
    cloudFrontName?: string;
    /** cdk Destroy した時に自動で削除するか(開発用) 。デフォルト:false */
    cdkAutoRemove?: boolean;
}

/**
 * フロントエンドアプリ コンストラクト
 */
export class CloudfrontAppConstruct extends Construct {
    public readonly distribution: cloudfront.CloudFrontWebDistribution;

    constructor(scope: Construct, id: string, props: CloudfrontAppConstructProps) {
        super(scope, id);

        // OAI
        const oai = new cloudfront.OriginAccessIdentity(this, 'Oai', {
            comment: "s3 web access.",
        });
        const frontBucketPolicy = new iam.PolicyStatement({
            effect: iam.Effect.ALLOW,
            actions: ["s3:GetObject"],
            principals: [
                new iam.CanonicalUserPrincipal(
                    oai.cloudFrontOriginAccessIdentityS3CanonicalUserId
                ),
            ],
            resources: [props.frontBucket.bucketArn + "/*"],
        });
        props.frontBucket.addToResourcePolicy(frontBucketPolicy);

        // ACM
        const acm_ = acm.Certificate.fromCertificateArn(this, 'Acm', props.acmArn);

        // Frontend Origin Config
        const originConfig: cloudfront.SourceConfiguration[] = [{
            s3OriginSource: {
                s3BucketSource: props.frontBucket,
                originAccessIdentity: oai,
            },
            behaviors: [
                {
                    isDefaultBehavior: true,
                    allowedMethods: cloudfront.CloudFrontAllowedMethods.GET_HEAD,
                    defaultTtl: cdk.Duration.seconds(0),
                    minTtl: cdk.Duration.seconds(0),
                    maxTtl: cdk.Duration.seconds(0),
                },
            ],
        }];
        // API Origin Config
        if (props.backendOriginConfig) {
            const backendOriginConfig: cloudfront.SourceConfiguration = {
                customOriginSource: {
                    domainName: props.backendOriginConfig.domainName,
                    originProtocolPolicy: cloudfront.OriginProtocolPolicy.HTTPS_ONLY,
                    httpPort: 443,
                    originHeaders: props.backendOriginConfig.originHeader
                },
                behaviors: [
                    {
                        pathPattern: props.backendOriginConfig.pathPattern || '/api/*',
                        allowedMethods: cloudfront.CloudFrontAllowedMethods.ALL,
                        defaultTtl: cdk.Duration.seconds(0),
                        minTtl: cdk.Duration.seconds(0),
                        maxTtl: cdk.Duration.seconds(0),
                        forwardedValues: {
                            queryString: true,
                            headers: props.backendOriginConfig.forwardedHeaders || ["Authorization"],
                        },
                    },
                ],
            };
            originConfig.push(backendOriginConfig)
        }

        // distribution
        this.distribution = new cloudfront.CloudFrontWebDistribution(this, 'Distribution', {
            viewerCertificate: cloudfront.ViewerCertificate.fromAcmCertificate(acm_, {
                aliases: [props.domainName]
            }),
            enableIpV6: false,
            defaultRootObject: "index.html",
            viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
            httpVersion: cloudfront.HttpVersion.HTTP2,
            priceClass: cloudfront.PriceClass.PRICE_CLASS_200,
            loggingConfig: props.accessLogBucket ? {
                bucket: props.accessLogBucket,
                includeCookies: true,
                prefix: "accesslog/",
            } : undefined,
            originConfigs: originConfig,
            webACLId: props.webAclId,
            errorConfigurations: props.errorConfigurations
        });
        if (props.cloudFrontName) {
            cdk.Tags.of(this.distribution).add('Name', props.cloudFrontName);
        }
    }
}