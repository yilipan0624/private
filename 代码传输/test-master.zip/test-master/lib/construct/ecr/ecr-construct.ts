import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_ecr as ecr } from 'aws-cdk-lib';

/**
 * ECRコンストラクトプロパティ
 */
type EcrConstructProps = {
    /**ECR リポジトリ名 */
    repositoryName: string;
    /** cdk Destroy した時に自動で削除するか(開発用) 。デフォルト:false */
    cdkAutoRemove?: boolean;
}

/**
 * ECRコンストラクト
 * @remarks ScanOnPushについて、リポジトリレベルの設定は非推奨となるため、レジストリレベルのスキャンフィルターにて設定すること。
 */
export class EcrConstruct extends Construct {
    public readonly ecrRepository: ecr.Repository;
    constructor(scope: Construct, id: string, props: EcrConstructProps) {
        super(scope, id);
        this.ecrRepository = new ecr.Repository(this, 'EcrRepository', {
            encryption: ecr.RepositoryEncryption.KMS,
            imageTagMutability: ecr.TagMutability.IMMUTABLE,
            repositoryName: props.repositoryName,
            removalPolicy: props.cdkAutoRemove ? cdk.RemovalPolicy.DESTROY : cdk.RemovalPolicy.RETAIN,
            lifecycleRules: [{
                description: 'expire | imageCountMoreThan (10) | any',
                maxImageCount: 10,
            }]
        });
        cdk.Tags.of(this.ecrRepository).add('Name', props.repositoryName);
    }
}