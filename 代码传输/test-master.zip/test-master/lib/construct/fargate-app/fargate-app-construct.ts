import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_ecr as ecr } from 'aws-cdk-lib';
import { aws_ecs as ecs } from 'aws-cdk-lib';
import { aws_ec2 as ec2 } from 'aws-cdk-lib';
import { aws_s3 as s3 } from 'aws-cdk-lib';
import { FargateAppPutS3TrigerBatchConstruct } from './fargate-app-put-s3-triger-batch-construct'
import { FargateAppServiceConstruct } from './fargate-app-service-construct'

/**
 * FargateAppConstruct プロパティ
 */
type FargateAppConstructProps = {
    /**
     * VPC
     */
    vpc: ec2.Vpc;
    /**
     * パブリックサブネット
     */
    publicSubnets: ec2.ISubnet[];
    /**
     * プライベートサブネット
     */
    privateSubnets: ec2.ISubnet[];
    /** ECSクラスタ名 */
    ecsClusterName?: string;
    /** cdk Destroy した時に自動で削除するか(開発用) 。デフォルト:false */
    cdkAutoRemove?: boolean;
}

type CreateAppServiceProps = {
    /** ECSタスク実行ロール名 */
    ecsTaskExecutionRoleName?: string;
    /** ECSタスクロール名 */
    ecsTaskRoleName?: string;
    /** ECSロググループ名 */
    ecsLogsGroupName?: string;
    /** ECSタスク名 */
    ecsTaskName?: string;
    /** 
     * ECS タスクの cpu 
     * @default 512;
     */
    cpu?: number;
    /**
     * ECS タスクのmemory 上限 (cpuに応じて設定できるメモリのテーブルがあるため注意)
     * @default 1024
    */
    memoryLimitMiB?: number;
    /** ECRリポジトリ*/
    ecrRepository: ecr.Repository;
    /** 
     * Dockerタグ
     * @default latest
     */
    dockerTag?: string;
    /**
     * 環境変数
     */
    environment?: { [key: string]: string };
    /**
     * 環境変数に設定するシークレット情報
     */
    secretEnv?: { [key: string]: cdk.aws_ecs.Secret } | undefined;
    /**
     * ECSサービス名
     */
    ecsServiceName?: string;
    /**
     * ECSサービスセキュリティグループ名
     */
    ecsServiceSgName?: string;
    /**
     * コンテナポート
     * @default 3000
     */
    containerPort?: number;
    /**
     * コンテナの希望数量
     * @default 1
     */
    containerDesiredCount?: number;
    /**
     * ヘルスチェックパス
     * @example /api/healthcheck
     */
    healthCheckPath?: string;
}

/**
 * FargateAppPutS3TrigerBatchConstruct プロパティ
 */
type CreatePutS3TrigerBatchProps = {
    /** ECSタスク実行ロール名 */
    ecsTaskExecutionRoleName?: string;
    /** ECSタスクロール名 */
    ecsTaskRoleName?: string;
    /** ECSロググループ名 */
    ecsLogsGroupName?: string;
    /** ECSタスク名 */
    ecsTaskName?: string;
    /** 
     * ECS タスクの cpu 
     * @default 512
     * */
    cpu?: number;
    /**
     * ECS タスクのmemory 上限 (cpuに応じて設定できるメモリのテーブルがあるため注意)
     * @default 1024
    */
    memoryLimitMiB?: number;
    /** ECRリポジトリ*/
    ecrRepository: ecr.Repository;
    /** 
     * Dockerタグ
     * @default latest
     */
    dockerTag?: string;
    /**
     * 環境変数
     */
    environment?: { [key: string]: string }
    /**
     * 環境変数に設定するシークレット情報
     */
    secretEnv?: { [key: string]: cdk.aws_ecs.Secret } | undefined;
    /**
     * イベントルール名
     */
    eventsRuleName?: string;
    /**
     * イベントトリガーとなるS3バケット
     */
    eventTrigerS3Bucket: s3.IBucket;
    /**
     * イベント説明
     */
    eventDescription?: string;
    /**
     * セキュリティグループ名
     */
    ecsTaskSgName?: string
}

/**
 * Fargateアプリケーションを作成
 */
export class FargateAppConstruct extends Construct {
    public readonly ecsCluster: ecs.Cluster;
    public readonly instanceProps: FargateAppConstructProps;

    constructor(scope: Construct, id: string, props: FargateAppConstructProps) {
        super(scope, id);
        this.instanceProps = props;

        // ECS クラスター
        this.ecsCluster = new ecs.Cluster(this, 'EcsCluster', {
            clusterName: props.ecsClusterName,
            containerInsights: true,
            vpc: props.vpc,
        });
        if (props.ecsClusterName) {
            cdk.Tags.of(this.ecsCluster).add('Name', props.ecsClusterName);
        }

    }

    /**
     * ECSクラスタにサービスを作成する
     * @param id 
     * @param props 
     */
    public createAppService(id: string, props: CreateAppServiceProps): FargateAppServiceConstruct {
        return new FargateAppServiceConstruct(this, id, {
            vpc: this.instanceProps.vpc,
            ecsCluster: this.ecsCluster,
            subnets: this.instanceProps.privateSubnets,
            ecsTaskExecutionRoleName: props.ecsTaskExecutionRoleName,
            ecsTaskRoleName: props.ecsTaskRoleName,
            ecsLogsGroupName: props.ecsLogsGroupName,
            ecsTaskName: props.ecsTaskName,
            cpu: props.cpu,
            memoryLimitMiB: props.memoryLimitMiB,
            ecrRepository: props.ecrRepository,
            dockerTag: props.dockerTag,
            environment: props.environment,
            secretEnv: props.secretEnv,
            ecsServiceName: props.ecsServiceName,
            ecsServiceSgName: props.ecsServiceSgName,
            containerPort: props.containerPort,
            containerDesiredCount: props.containerDesiredCount,
            cdkAutoRemove: this.instanceProps.cdkAutoRemove,
            healthCheckPath: props.healthCheckPath
        });
    }

    /**
     * ECSクラスタに Put S3トリガーのバッチを作成する。
     * @param id 
     * @param props 
     * @returns 
     */
    public createPutS3TrigerBatch(id: string, props: CreatePutS3TrigerBatchProps): FargateAppPutS3TrigerBatchConstruct {
        return new FargateAppPutS3TrigerBatchConstruct(this, id, {
            ecsTaskExecutionRoleName: props.ecsTaskExecutionRoleName,
            ecsTaskRoleName: props.ecsTaskRoleName,
            ecsLogsGroupName: props.ecsLogsGroupName,
            ecsTaskName: props.ecsTaskName,
            cpu: props.cpu,
            memoryLimitMiB: props.memoryLimitMiB,
            ecrRepository: props.ecrRepository,
            dockerTag: props.dockerTag,
            environment: props.environment,
            secretEnv: props.secretEnv,
            ecsCluster: this.ecsCluster,
            vpc: this.instanceProps.vpc,
            subnets: this.instanceProps.privateSubnets,
            eventsRuleName: props.eventsRuleName,
            eventTrigerS3Bucket: props.eventTrigerS3Bucket,
            eventDescription: props.eventDescription,
            ecsTaskSgName: props.ecsTaskSgName,
            cdkAutoRemove: this.instanceProps.cdkAutoRemove,
        });
    }

}