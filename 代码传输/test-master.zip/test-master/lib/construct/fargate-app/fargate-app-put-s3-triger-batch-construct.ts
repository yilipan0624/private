import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_ecr as ecr } from 'aws-cdk-lib';
import { aws_ecs as ecs } from 'aws-cdk-lib';
import { aws_iam as iam } from 'aws-cdk-lib';
import { aws_logs as logs } from 'aws-cdk-lib';
import { aws_events as events } from 'aws-cdk-lib';
import { aws_events_targets as eventsTargets } from 'aws-cdk-lib';
import { aws_ec2 as ec2 } from 'aws-cdk-lib';
import { aws_s3 as s3 } from 'aws-cdk-lib';


/**
 * FargateAppPutS3TrigerBatchConstruct プロパティ
 */
type FargateAppPutS3TrigerBatchConstructProps = {
    /** ECSタスク実行ロール名 */
    ecsTaskExecutionRoleName?: string;
    /** ECSタスクロール名 */
    ecsTaskRoleName?: string;
    /** ECSロググループ名 */
    ecsLogsGroupName?: string;
    /** ECSタスク名 */
    ecsTaskName?: string;
    /** 
     * ECS タスクの cpu 
     * @default 512
     * */
    cpu?: number;
    /**
     * ECS タスクのmemory 上限 (cpuに応じて設定できるメモリのテーブルがあるため注意)
     * @default 1024
    */
    memoryLimitMiB?: number;
    /** ECRリポジトリ*/
    ecrRepository: ecr.Repository;
    /** 
     * Dockerタグ
     * @default latest
     */
    dockerTag?: string;
    /**
     * 環境変数
     */
    environment?: { [key: string]: string }
    /**
     * 環境変数に設定するシークレット情報
     */
    secretEnv?: { [key: string]: cdk.aws_ecs.Secret } | undefined;
    /**
     * ECSクラスタ
     */
    ecsCluster: ecs.Cluster;
    /**
     * VPC
     */
    vpc: ec2.Vpc;
    /**
     * サブネット
     */
    subnets: ec2.ISubnet[];
    /**
     * イベントルール名
     */
    eventsRuleName?: string;
    /**
     * イベントトリガーとなるS3バケット
     */
    eventTrigerS3Bucket: s3.IBucket;
    /**
     * イベント説明
     */
    eventDescription?: string;
    /** cdk Destroy した時に自動で削除するか(開発用) 。デフォルト:false */
    cdkAutoRemove?: boolean;
    /**
     * セキュリティグループ名
     */
    ecsTaskSgName?: string
}

/**
 * Put S3トリガーのバッチを作成
 */
export class FargateAppPutS3TrigerBatchConstruct extends Construct {
    public readonly ecsTask: ecs.FargateTaskDefinition;
    public readonly ecsLogsGroup: logs.LogGroup;
    public readonly eventRule: events.Rule;

    constructor(scope: Construct, id: string, props: FargateAppPutS3TrigerBatchConstructProps) {
        super(scope, id);

        // ECS TaskExecutionRole
        const ecsTaskExecutionRole = new iam.Role(this, 'EcsTaskExecutionRole', {
            roleName: props.ecsTaskExecutionRoleName,
            assumedBy: new iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            managedPolicies: [
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    "service-role/AmazonECSTaskExecutionRolePolicy"
                ),
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    "AmazonEC2ContainerRegistryPowerUser"
                ),
            ],
        });
        if (props.ecsTaskExecutionRoleName) {
            cdk.Tags.of(ecsTaskExecutionRole).add('Name', props.ecsTaskExecutionRoleName);
        }

        // ECS TaskRole
        const ecsTaskRole = new iam.Role(this, 'EcsTaskRole', {
            roleName: props.ecsTaskRoleName,
            assumedBy: new iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            managedPolicies: [
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    "AmazonS3FullAccess"
                ),
            ],
            inlinePolicies: {
                secretsmanager: new iam.PolicyDocument({
                    statements: [
                        new iam.PolicyStatement({
                            effect: iam.Effect.ALLOW,
                            resources: ["*"],
                            actions: [
                                "secretsmanager:GetSecretValue",
                                "secretsmanager:DescribeSecret",
                            ],
                        }),
                    ],
                }),
            },
        });
        if (props.ecsTaskRoleName) {
            cdk.Tags.of(ecsTaskRole).add('Name', props.ecsTaskRoleName);
        }

        // ECS タスク定義
        this.ecsTask = new ecs.FargateTaskDefinition(this, "EcsTask", {
            executionRole: ecsTaskExecutionRole,
            taskRole: ecsTaskRole,
            family: props.ecsTaskName,
            cpu: 512,
            memoryLimitMiB: 1024,
        });
        if (props.ecsTaskName) {
            cdk.Tags.of(this.ecsTask).add('Name', props.ecsTaskName);
        }

        // ECSタスク ロググループ
        this.ecsLogsGroup = new logs.LogGroup(this, "EcsLogsGroup", {
            logGroupName: props.ecsLogsGroupName,
            removalPolicy: props.cdkAutoRemove ? cdk.RemovalPolicy.DESTROY : cdk.RemovalPolicy.RETAIN,
            retention: cdk.aws_logs.RetentionDays.ONE_YEAR
        });
        if (props.ecsLogsGroupName) {
            cdk.Tags.of(this.ecsLogsGroup).add('Name', props.ecsLogsGroupName);
        }

        //ECS Security Group
        const sg = new ec2.SecurityGroup(this, 'sg-ec2-bastion', {
            vpc: props.vpc,
            securityGroupName: props.ecsTaskSgName,
            allowAllOutbound: true
        });
        if (props.ecsTaskSgName) {
            cdk.Tags.of(sg).add('Name', props.ecsTaskSgName);
        }

        // ECSタスク コンテナ
        const container = this.ecsTask.addContainer('EcsContainer', {
            image: ecs.ContainerImage.fromEcrRepository(
                props.ecrRepository,
                props.dockerTag
            ),
            cpu: props.cpu || 512,
            memoryLimitMiB: props.memoryLimitMiB || 1024,
            logging: ecs.LogDrivers.awsLogs({
                logGroup: this.ecsLogsGroup,
                streamPrefix: "event",
            }),
            environment: props.environment,
            secrets: props.secretEnv,
        });
        
        //タスク定義のARNからリビジョンを削除
        const taskDefinition = this.ecsTask;
        const splitTaskArn = cdk.Fn.split(':', this.ecsTask.taskDefinitionArn);
        const taskDefinitionArn = `${cdk.Fn.select(0, splitTaskArn)}:${cdk.Fn.select(1, splitTaskArn)}:${cdk.Fn.select(2, splitTaskArn)}:${cdk.Fn.select(3, splitTaskArn)}:${cdk.Fn.select(4, splitTaskArn)}:${cdk.Fn.select(5, splitTaskArn)}`;
        Object.assign(taskDefinition, { taskDefinitionArn: taskDefinitionArn });

        // イベントルール
        this.eventRule = new events.Rule(this, "MasterfileUploadRule", {
            ruleName: props.eventsRuleName,
            description: props.eventDescription,
            eventPattern: {
                source: ["aws.s3"],
                detailType: ["Object Created"],
                detail: {
                    bucket: {
                        name: [props.eventTrigerS3Bucket.bucketName],
                    },
                },
            },
            targets: [
                new eventsTargets.EcsTask({
                    cluster: props.ecsCluster,
                    taskDefinition: taskDefinition,
                    taskCount: 1,
                    securityGroups: [sg],
                    subnetSelection: { subnets: props.subnets },
                    containerOverrides: [
                        {
                            containerName: container.containerName,
                            environment: [
                                {
                                    name: "UPLOADED_S3_OBJECT_KEY",
                                    value: `${events.EventField.fromPath("$.detail.object.key")}`,
                                },
                            ],
                        },
                    ],
                }),
            ],
        });
        if (props.eventsRuleName) {
            cdk.Tags.of(this.eventRule).add('Name', props.eventsRuleName);
        }
    }
}