import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_ecr as ecr } from 'aws-cdk-lib';
import { aws_ecs as ecs } from 'aws-cdk-lib';
import { aws_iam as iam } from 'aws-cdk-lib';
import { aws_logs as logs } from 'aws-cdk-lib';
import { aws_ec2 as ec2 } from 'aws-cdk-lib';
import { aws_sns as sns } from 'aws-cdk-lib';
import { aws_cloudwatch as cw } from 'aws-cdk-lib';
import { aws_cloudwatch_actions as cw_actions } from 'aws-cdk-lib';

/**
 * ECRコンストラクトプロパティ
 */
type FargateAppServiceConstructProps = {
    /** ECSタスク実行ロール名 */
    ecsTaskExecutionRoleName?: string;
    /** ECSタスクロール名 */
    ecsTaskRoleName?: string;
    /** ECSロググループ名 */
    ecsLogsGroupName?: string;
    /** ECSタスク名 */
    ecsTaskName?: string;
    /** 
     * ECS タスクの cpu 
     * @default 512;
     */
    cpu?: number;
    /**
     * ECS タスクのmemory 上限 (cpuに応じて設定できるメモリのテーブルがあるため注意)
     * @default 1024
    */
    memoryLimitMiB?: number;
    /** ECRリポジトリ*/
    ecrRepository: ecr.Repository;
    /** 
     * Dockerタグ
     * @default latest
     */
    dockerTag?: string;
    /**
     * 環境変数
     */
    environment?: { [key: string]: string };
    /**
     * 環境変数に設定するシークレット情報
     */
    secretEnv?: { [key: string]: cdk.aws_ecs.Secret } | undefined;
    /**
     * ECSサービス名
     */
    ecsServiceName?: string;
    /**
     * ECSサービスセキュリティグループ名
     */
    ecsServiceSgName?: string;
    /**
     * ECSクラスタ
     */
    ecsCluster: ecs.Cluster;
    /**
     * VPC
     */
    vpc: ec2.Vpc;
    /**
     * サブネット
     */
    subnets: ec2.ISubnet[];
    /**
     * コンテナポート
     * @default 3000
     */
    containerPort?: number;
    /**
     * コンテナの希望数量
     * @default 1
     */
    containerDesiredCount?: number;
    /** cdk Destroy した時に自動で削除するか(開発用) 。デフォルト:false */
    cdkAutoRemove?: boolean;
    /**
     * ヘルスチェックパス
     * @example /api/healthcheck
     */
    healthCheckPath?: string;
}

/**
 * サービス系ECSタスクコンストラクト
 */
export class FargateAppServiceConstruct extends Construct {
    public readonly instanceProps: FargateAppServiceConstructProps
    public readonly ecsTask: ecs.FargateTaskDefinition;
    public readonly ecsService: ecs.FargateService;
    public readonly ecsCluster: ecs.ICluster;
    public readonly ecsLogsGroup: logs.LogGroup;
    public readonly containerPort: number;
    public readonly healthCheckPath: string | undefined;

    constructor(scope: Construct, id: string, props: FargateAppServiceConstructProps) {
        super(scope, id);
        this.instanceProps = props;
        this.containerPort = props.containerPort || 3000;
        this.healthCheckPath = props.healthCheckPath;
        this.ecsCluster = props.ecsCluster;

        // ECS TaskExecutionRole
        const ecsTaskExecutionRole = new iam.Role(this, 'EcsTaskExecutionRole', {
            roleName: props.ecsTaskExecutionRoleName,
            assumedBy: new iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            managedPolicies: [
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    "service-role/AmazonECSTaskExecutionRolePolicy"
                ),
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    "AmazonEC2ContainerRegistryPowerUser"
                ),
            ],
        });
        if (props.ecsTaskExecutionRoleName) {
            cdk.Tags.of(ecsTaskExecutionRole).add('Name', props.ecsTaskExecutionRoleName);
        }

        // ECS TaskRole
        const ecsTaskRole = new iam.Role(this, 'EcsTaskRole', {
            roleName: props.ecsTaskRoleName,
            assumedBy: new iam.ServicePrincipal("ecs-tasks.amazonaws.com"),
            managedPolicies: [
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    "AmazonS3FullAccess"
                ),
            ],
            inlinePolicies: {
                secretsmanager: new iam.PolicyDocument({
                    statements: [
                        new iam.PolicyStatement({
                            effect: iam.Effect.ALLOW,
                            resources: ["*"],
                            actions: [
                                "secretsmanager:GetSecretValue",
                                "secretsmanager:DescribeSecret",
                            ],
                        }),
                    ],
                }),
            },
        });
        if (props.ecsTaskRoleName) {
            cdk.Tags.of(ecsTaskRole).add('Name', props.ecsTaskRoleName);
        }

        // ECS タスク定義
        this.ecsTask = new ecs.FargateTaskDefinition(this, "EcsTaskDef", {
            executionRole: ecsTaskExecutionRole,
            taskRole: ecsTaskRole,
            family: props.ecsTaskName,
            cpu: 512,
            memoryLimitMiB: 1024,
        });
        if (props.ecsTaskName) {
            cdk.Tags.of(this.ecsTask).add('Name', props.ecsTaskName);
        }

        // ECSタスク ロググループ
        this.ecsLogsGroup = new logs.LogGroup(this, "EcsLogsGroup", {
            logGroupName: props.ecsLogsGroupName,
            removalPolicy: props.cdkAutoRemove ? cdk.RemovalPolicy.DESTROY : cdk.RemovalPolicy.RETAIN,
            retention: cdk.aws_logs.RetentionDays.ONE_YEAR
        });
        if (props.ecsLogsGroupName) {
            cdk.Tags.of(this.ecsLogsGroup).add('Name', props.ecsLogsGroupName);
        }

        // ECSタスク コンテナ
        const healthCheckUrl = `http://localhost:${props.containerPort || '80'}${props.healthCheckPath}`
        this.ecsTask.addContainer('EcsContainer', {
            image: ecs.ContainerImage.fromEcrRepository(
                props.ecrRepository,
                props.dockerTag
            ),
            cpu: props.cpu || 512,
            memoryLimitMiB: props.memoryLimitMiB || 1024,
            logging: ecs.LogDrivers.awsLogs({
                logGroup: this.ecsLogsGroup,
                streamPrefix: "event",
            }),
            environment: props.environment,
            secrets: props.secretEnv,
            portMappings: [{ containerPort: this.containerPort }],
            healthCheck: props.healthCheckPath ? { command: ["CMD-SHELL", `curl -f ${healthCheckUrl} || exit 1`] } : undefined
        });

        // ECSサービス SG
        const sg = new ec2.SecurityGroup(this, 'sg-ec2-bastion', {
            vpc: props.vpc,
            securityGroupName: props.ecsServiceSgName,
            allowAllOutbound: true
        });
        if (props.ecsServiceSgName) {
            cdk.Tags.of(sg).add('Name', props.ecsServiceSgName);
        }

        // ECSサービス
        this.ecsService = new ecs.FargateService(this, "EcsService", {
            cluster: props.ecsCluster,
            taskDefinition: this.ecsTask,
            vpcSubnets: { subnets: props.subnets },
            desiredCount: props.containerDesiredCount === undefined ? 1 : props.containerDesiredCount,
            serviceName: props.ecsServiceName,
            securityGroups: [sg],
        });
        if (props.ecsServiceName) {
            cdk.Tags.of(this.ecsService).add('Name', props.ecsServiceName);
        }
    }

    /**
     * サービスCPUアラームを追加
     * @param id
     * @param alarmTopic 通知するSNSトピック
     * @param thresholdRate CPU使用率のアラート閾値
     * @param alarmName アラーム名
     */
    addServiceCpuArarm(id: string, alarmTopic: sns.ITopic, thresholdRate = 0.8, alarmName?: string) {
        const alarm = this.ecsService
            .metricCpuUtilization({
                period: cdk.Duration.minutes(5),
                statistic: cw.Statistic.AVERAGE,
            })
            .createAlarm(this, id, {
                evaluationPeriods: 5,
                datapointsToAlarm: 1,
                threshold: thresholdRate * 100,
                comparisonOperator: cw.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
                actionsEnabled: true,
                treatMissingData: cw.TreatMissingData.BREACHING,
                alarmName: alarmName
            });
        if (alarmName) {
            cdk.Tags.of(alarm).add('Name', alarmName);
        }
        alarm.addAlarmAction(new cw_actions.SnsAction(alarmTopic));
    }
    /**
      * サービスメモリアラームを追加
     * @param id
     * @param alarmTopic 通知するSNSトピック
     * @param thresholdRate CPU使用率のアラート閾値
     * @param alarmName アラーム名
      */
    addServiceMemoryArarm(id: string, alarmTopic: sns.ITopic, thresholdRate = 0.8, alarmName?: string) {
        const alarm = this.ecsService
            .metricMemoryUtilization({
                period: cdk.Duration.minutes(5),
                statistic: cw.Statistic.AVERAGE,
            })
            .createAlarm(this, id, {
                evaluationPeriods: 5,
                datapointsToAlarm: 1,
                threshold: thresholdRate * 100,
                comparisonOperator: cw.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
                actionsEnabled: true,
                treatMissingData: cw.TreatMissingData.BREACHING,
                alarmName,
            });
        if (alarmName) {
            cdk.Tags.of(alarm).add('Name', alarmName);
        }
        alarm.addAlarmAction(new cw_actions.SnsAction(alarmTopic));
    }
    /**
    * ECS サービスRunTask の数量を追加
    * @param id
    * @param alarmTopic 通知するSNSトピック
    * @param thresholdRate 必要な稼働タスク数
    * @param alarmName アラーム名
    */
    addRunningTaskCountArarm(id: string, alarmTopic: sns.ITopic, thresholdRate = 1, alarmName?: string) {
        const metric = new cw.Metric({
            namespace: 'ECS/ContainerInsights',
            metricName: 'RunningTaskCount',
            dimensionsMap: {
                ClusterName: this.ecsCluster.clusterName,
                ServiceName: this.ecsService.serviceName,
            },
            period: cdk.Duration.minutes(5),
            statistic: cw.Statistic.AVERAGE,
            // label: "${PROP('MetricName')} /${PROP('Period')}sec",
            // unit: cw.Unit.COUNT,
        });
        const alarm = metric.createAlarm(this, id, {
            evaluationPeriods: 1,
            datapointsToAlarm: 1,
            threshold: thresholdRate,
            comparisonOperator: cw.ComparisonOperator.LESS_THAN_THRESHOLD,
            actionsEnabled: true,
            treatMissingData: cw.TreatMissingData.BREACHING,
            alarmName,
        });
        if (alarmName) {
            cdk.Tags.of(alarm).add('Name', alarmName);
        }
        alarm.addAlarmAction(new cw_actions.SnsAction(alarmTopic));
    }
}