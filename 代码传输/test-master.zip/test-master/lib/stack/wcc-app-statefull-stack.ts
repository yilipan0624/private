import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NamingStackProps } from '../../utils/commonTypes'
import { ResourceNameBuilder, InstanceType } from '../../utils/helpers'
import { RdsAuroraMysqlConstruct } from '../construct/rds-aurora-mysql/rds-aurora-mysql-construct';
import { aws_sns as sns } from 'aws-cdk-lib';
import { VpcConstruct } from '../construct/vpc/vpc-construct';
import { EcrConstruct } from '../construct/ecr/ecr-construct';
import { aws_ecr as ecr } from 'aws-cdk-lib';
import { aws_s3 as s3 } from 'aws-cdk-lib';
import { S3CommonBucketConstruct } from '../construct/s3-common-bucket/s3-common-bucket-construct';
import { S3S3logBucketConstruct } from '../construct/s3-s3log-bucket/s3-s3log-bucket-construct';
import { LogsS3BackupConstruct } from '../construct/logs-s3-backup/logs-s3-backup-construct';

/**
 * アプリケーションステートフルスタックのプロパティ
 */
type WccAppStatefullStackProps = {
    /** ネーミングプロパティ */
    namingStackProps: NamingStackProps;
    vpc: VpcConstruct;
    /**
     * RDSインスタンスタイプ
     * @default t3.medium
     */
    rdsInstaceTypeStr?: string;
    /**
     * RDSインスタンス数 (2以上指定でレプリカ作成)
     * @default 1
     */
    rdsInstances?: number,
    /**
     * バックアップ期間
     * @default no backup
     */
    rdsBackupDays?: number
    /**
     * アラート用SnsTopicのArn
     * @default アラームは作成されない
     */
    snsAlarmTopicArn?: string;
    /**
     * アクセスログ格納用S3バケット
     */
    s3AccessLogBucket?: S3S3logBucketConstruct;
    /** datasync用IAMロール */
    dataSyncRoleArnList?: string[]
    /**
     * dataSyncクロスアカウントId
     * クロスアカウントでDatasyncする場合は必須
     */
    dataSyncCorssAccountId?: string
} & cdk.StackProps

/**
 * アプリケーションステートフルスタック
 */
export class WccAppStatefullStack extends cdk.Stack {
    /** RDS */
    readonly rds: RdsAuroraMysqlConstruct
    /** データ連携・変換バッチ用 ECR */
    readonly ecrRepositoryCrcb: ecr.Repository;
    /** ロジック実行・管理 app 用 ECR */
    readonly ecrRepositoryLems: ecr.Repository;
    /** マスタアップロードバッチ用 ECR */
    readonly ecrRepositoryMub: ecr.Repository;
    /**
     * マスタデータバケット
     */
    readonly masterFilesBucket: s3.IBucket;
    /**
     * 変換後健診データバケット
     */
    readonly uploadCheckupResultFilesBucket: s3.IBucket;
    /**
     * 精査前処理後データバケット
     */
    readonly executedCheckupResultFilesBucket: s3.IBucket;

    constructor(scope: Construct, id: string, props: WccAppStatefullStackProps) {
        super(scope, id, props);

        //定数
        const rdsSnapshotBuckupRegion = 'ap-northeast-3' // RDS スナップショットのバックアップ先
        const rdsdeleteSnapshotScheduleCronExpression = 'cron(0 15 * * ? *)' // DRしたRDSスナップショットの削除時間

        /** CWLバックアップ用バケット */
        const cwlBackupS3 = new S3S3logBucketConstruct(this, 'CwlBackupS3', {
            bucketName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 's3',
                use: 'rds-cwl-backup',
                ...props.namingStackProps
            }),
            deleteObjectsLifeCyclePolicy: {
                expirationDays: 7,
                lifecycleName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'lifecycle',
                    use: 'rds-cwl-backup',
                    ...props.namingStackProps
                })
            },
            dataSyncRoleArnList: props.dataSyncRoleArnList,
            dataSyncCorssAccountId: props.dataSyncCorssAccountId,

            cdkAutoRemove: true,
        });
        /** RDS */
        this.rds = new RdsAuroraMysqlConstruct(this, 'AuroraMysql', {
            privateSubnets: props.vpc.privateSubnets,
            vpc: props.vpc.vpc,
            backupDays: props.rdsBackupDays,
            rdsInstaceTypeStr: props.rdsInstaceTypeStr,
            rdsInstances: props.rdsInstances,
            rdsClusterName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'aurora',
                use: 'cluster',
                ...props.namingStackProps
            }),
            rdsInstanceIdentifierBase: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'aurora',
                use: 'instance',
                ...props.namingStackProps
            }) + '-',
            rdsParameterGroupName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'parametergrp',
                use: 'aurora',
                ...props.namingStackProps
            }),
            rdsSecretName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'sm',
                use: 'aurora',
                ...props.namingStackProps
            }),
            rdsSecurityGroupName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'sg',
                use: 'aurora',
                ...props.namingStackProps
            }),
            rdsSubnetGroupName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'subnetgrp',
                use: 'private',
                ...props.namingStackProps
            }),
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey) || false,
        });
        // RDS アラーム設定
        if (props.snsAlarmTopicArn) {
            const topic = sns.Topic.fromTopicArn(this, 'SnsTopic', props.snsAlarmTopicArn);
            this.rds.addCpuArarm('CpuUtilization', topic, 0.85,
                ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'alarm',
                    use: 'rds-cpu-utilization',
                    ...props.namingStackProps
                })
            );
            const memorySize = InstanceType.retriveInfo(this.rds.rdsInstaceTypeStr);
            if (memorySize) {
                this.rds.addMemoryArarm('MemoryUtilization', topic, memorySize.memory * (1024 ** 2), 0.15,
                    ResourceNameBuilder.makeResourceNameStr({
                        serviceName: 'alarm',
                        use: 'rds-memory-utilization',
                        ...props.namingStackProps
                    })
                );
            }
        }

        // スナップショットファンクション作成
        this.rds.createSnapshotFunctions('copySnapshot', {
            copySnapshotProps: {
                destinationRegion: rdsSnapshotBuckupRegion,
                eventsName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'event',
                    use: 'copy-snapshot',
                    ...props.namingStackProps
                }),
                functionName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'lambda',
                    use: 'copy-snapshot',
                    ...props.namingStackProps
                }),
            },
            deleteSnapshotProps: {
                deleteDays: props.rdsBackupDays,
                scheduleCronExpression: rdsdeleteSnapshotScheduleCronExpression,
                eventsName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'event',
                    use: 'delete-snapshot',
                    ...props.namingStackProps
                }),
                functionName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'lambda',
                    use: 'delete-snapshot',
                    ...props.namingStackProps
                }),
            }
        });
        // RDSログバックアップ
        for (const [k_, v_] of Object.entries(this.rds.rdsLogs)) {
            new LogsS3BackupConstruct(this, `${k_}LogBackup`, {
                destinationBucket: cwlBackupS3.s3Bucket,
                sourceLogGroup: v_,
                streamName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'stream',
                    use: `rds-${k_}`,
                    ...props.namingStackProps
                }),
                deliveryStreamName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'deliveryStream',
                    use: `rds-${k_}`,
                    ...props.namingStackProps
                })
            });
        }

        /** アプリケーション用ECR */
        // データ連携・変換バッチ用 ECR
        this.ecrRepositoryCrcb = new EcrConstruct(this, 'EcrRepositoryCrcb', {
            repositoryName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecr',
                use: `crcb`,
                ...props.namingStackProps
            }),
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey) || false,
        }).ecrRepository;

        // ロジック実行・管理 app 用 ECR
        this.ecrRepositoryLems = new EcrConstruct(this, 'EcrRepositoryLems', {
            repositoryName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecr',
                use: `lems`,
                ...props.namingStackProps
            }),
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey) || false,
        }).ecrRepository;

        // マスタアップロードバッチ用 ECR
        this.ecrRepositoryMub = new EcrConstruct(this, 'EcrRepositoryMub', {
            repositoryName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecr',
                use: `mub`,
                ...props.namingStackProps
            }),
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey) || false,
        }).ecrRepository;

        /** マスタデータバケット */
        this.masterFilesBucket = new S3CommonBucketConstruct(this, 's3-master-files', {
            bucketName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 's3',
                use: `master-files`,
                ...props.namingStackProps
            }),
            eventBridgeEnabled: true,
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey) || false,
            serverAccessLogsBucket: props.s3AccessLogBucket?.s3Bucket,
        }).s3Bucket;

        // 変換後健診データバケット
        this.uploadCheckupResultFilesBucket = new S3CommonBucketConstruct(this, 's3-uploaded-checkup-result-files', {
            bucketName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 's3',
                use: `uploaded-checkup-result-files`,
                ...props.namingStackProps
            }),
            eventBridgeEnabled: true,
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey) || false,
            serverAccessLogsBucket: props.s3AccessLogBucket?.s3Bucket,
        }).s3Bucket;

        // 精査前処理後データバケット
        this.executedCheckupResultFilesBucket = new S3CommonBucketConstruct(this, 's3-executed-checkup-result-files', {
            bucketName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 's3',
                use: `executed-checkup-result-files`,
                ...props.namingStackProps
            }),
            eventBridgeEnabled: false,
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey) || false,
            serverAccessLogsBucket: props.s3AccessLogBucket?.s3Bucket,
        }).s3Bucket;
    }
}