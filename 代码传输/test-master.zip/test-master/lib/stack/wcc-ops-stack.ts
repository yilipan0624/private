import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NamingStackProps } from '../../utils/commonTypes';
import { ResourceNameBuilder } from '../../utils/helpers';
import { aws_ec2 as ec2 } from 'aws-cdk-lib';
import { aws_iam as iam } from 'aws-cdk-lib';

type WccOpsStackProps = {
    namingStackProps: NamingStackProps;
    vpc: ec2.Vpc;
    privateSubnets: ec2.ISubnet[];
    /**
     * EC2のインスタンスタイプ
     * @example t3.micro
     */
    instanceType?: string;
} & cdk.StackProps

export class WccOpsStack extends cdk.Stack {

    constructor(scope: Construct, id: string, props: WccOpsStackProps) {
        super(scope, id, props);

        // Ec2 Security Group
        const sgName = ResourceNameBuilder.makeResourceNameStr({
            serviceName: 'sg',
            use: 'bastion',
            ...props.namingStackProps
        });
        const sg = new ec2.SecurityGroup(this, 'sg-ec2-bastion', {
            vpc: props.vpc,
            securityGroupName: sgName,
            allowAllOutbound: true
        });
        cdk.Tags.of(sg).add('Name', sgName);

        // Ec2 IAM Role
        const roleName = ResourceNameBuilder.makeResourceNameStr({
            serviceName: 'role',
            use: 'bastion',
            ...props.namingStackProps
        });
        const role = new iam.Role(this, 'role-ec2-bastion', {
            assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'),
            description: 'bastion ec2 role',
            roleName: roleName,
            managedPolicies: [iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMManagedInstanceCore')],
        });
        cdk.Tags.of(role).add('Name', roleName);

        // EC2 Instance
        const instanceName = ResourceNameBuilder.makeResourceNameStr({
            serviceName: 'ec2',
            use: 'bastion',
            ...props.namingStackProps
        });
        const instance = new ec2.Instance(this, 'ec2-bastion',
            {
                vpc: props.vpc,
                vpcSubnets: { subnets: props.privateSubnets },
                instanceType: new ec2.InstanceType(props.instanceType || 't3.micro'),
                machineImage: ec2.MachineImage.latestAmazonLinux({ generation: ec2.AmazonLinuxGeneration.AMAZON_LINUX_2 }),
                instanceName: instanceName,
                role: role,
                securityGroup: sg,
                blockDevices: [{
                    deviceName: `/dev/xvda`,
                    volume: ec2.BlockDeviceVolume.ebs(8, {
                        encrypted: true,
                        volumeType: ec2.EbsDeviceVolumeType.GP3,
                        iops: 3000,
                    }),
                }]
            }
        );
        instance.userData.addCommands(
            `hostnamectl set-hostname ${instanceName}`,
            'echo "preserve_hostname: true" >> /etc/cloud/cloud.cfg',
            'timedatectl set-timezone Asia/Tokyo',
            'yum update -y'
        );
        // EC2終了保護
        if (!(/^ctc[0-9]$/.test(props.namingStackProps.envKey))) {
            const cfnInstance = instance.node.defaultChild as ec2.CfnInstance;
            cfnInstance.disableApiTermination = true;
        }

        cdk.Tags.of(instance).add('Name', instanceName);
    }
}