import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { NamingStackProps } from '../../utils/commonTypes';
import { ResourceNameBuilder } from '../../utils/helpers';
import { aws_ecr as ecr } from 'aws-cdk-lib';
import { aws_ecs as ecs } from 'aws-cdk-lib';
import { aws_secretsmanager as sm } from 'aws-cdk-lib';
import { aws_s3 as s3 } from 'aws-cdk-lib';
import { FargateAppConstruct } from '../construct/fargate-app/fargate-app-construct';
import { FargateAppPutS3TrigerBatchConstruct } from '../construct/fargate-app/fargate-app-put-s3-triger-batch-construct';
import { FargateAppServiceConstruct } from '../construct/fargate-app/fargate-app-service-construct';
import { AlbConstruct } from '../construct/alb/alb-construct';
import { VpcConstruct } from '../construct/vpc/vpc-construct';
import { LogsS3BackupConstruct } from '../construct/logs-s3-backup/logs-s3-backup-construct';
import { S3S3logBucketConstruct } from '../construct/s3-s3log-bucket/s3-s3log-bucket-construct';
import { aws_sns as sns } from 'aws-cdk-lib';


/**
 * WccAppBackendStack プロパティ
 */
type WccAppBackendStackProps = {
    namingStackProps: NamingStackProps;
    /**
     * VPC
     */
    vpc: VpcConstruct;
    /**
     * ロジック実行・管理APP ECSプロパティ
     */
    lemsProps: ContainerProps;
    /**
     * データ連携・変換バッチ ECSプロパティ
     */
    crcbProps: ContainerProps;
    /**
     * 取り込み用バッチ ECSプロパティ
     */
    mubProps: ContainerProps;
    /**
     * マスタデータバケット
     */
    masterFilesBucket: s3.IBucket;
    /**
     * 変換後健診データバケット
     */
    uploadCheckupResultFilesBucket: s3.IBucket;
    /**
     * 精査前処理後データバケット
     */
    executedCheckupResultFilesBucket: s3.IBucket;
    /**
     * db接続情報を含むシークレットマネージャ
     */
    dbSecret?: sm.Secret;
    /**
     * アラート用SnsTopicのArn
     * @default アラームは作成されない
     */
    snsAlarmTopicArn?: string;
    /**
     * ターゲットグループを登録するALB
     */
    alb: AlbConstruct;
    /**
     * ターゲットグループ登録するCloudFront条件ヘッダ
     */
    cloudFrontAccessPermissionHeader?: { key: string, val: string }
    /** datasync用IAMロール */
    dataSyncRoleArnList?: string[]
    /**
     * dataSyncクロスアカウントId
     * クロスアカウントでDatasyncする場合は必須
     */
    dataSyncCorssAccountId?: string
} & cdk.StackProps

/**
 * ロジック実行・管理APP ECSプロパティ
 */
type ContainerProps = {
    /**
     * コンテナの希望数量
     * @default 0
     */
    containerDesiredCount?: number;
    /** 
     * ECS タスクの cpu 
     * @default 512;
     */
    cpu: number;
    /**
     * ECS タスクのmemory 上限 (cpuに応じて設定できるメモリのテーブルがあるため注意)
     * @default 1024
    */
    memoryLimitMiB: number;
    /** ECRリポジトリ*/
    ecrRepository: ecr.Repository;
    /** 
     * Dockerタグ
     * @default latest
     */
    dockerTag?: string;
}

/**
 * アプリケーションバックエンドスタック
 */
export class WccAppBackendStack extends cdk.Stack {
    /** Fargateアプリケーション */
    public readonly fargateApp: FargateAppConstruct;
    /** Lemsサービス */
    public readonly fargateAppLems: FargateAppServiceConstruct;
    /** Mubタスク */
    public readonly fargateAppMub: FargateAppPutS3TrigerBatchConstruct;
    /** Crcbタスク */
    public readonly fargateAppCrcb: FargateAppPutS3TrigerBatchConstruct;

    constructor(scope: Construct, id: string, props: WccAppBackendStackProps) {
        super(scope, id, props);

        // 定数
        const lemsContainerPort = 3000; // lems コンテナポート
        const lemsHealthCheckPath = '/api/healthcheck';

        /** CWLバックアップ用バケット */
        const cwlBackupS3 = new S3S3logBucketConstruct(this, 'CwlBackupS3', {
            bucketName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 's3',
                use: 'app-cwl-backup',
                ...props.namingStackProps
            }),
            deleteObjectsLifeCyclePolicy: {
                expirationDays: 7,
                lifecycleName: ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'lifecycle',
                    use: 'app-cwl-backup',
                    ...props.namingStackProps
                })
            },
            cdkAutoRemove: true,
            dataSyncRoleArnList: props.dataSyncRoleArnList,
            dataSyncCorssAccountId: props.dataSyncCorssAccountId,

        });

        /** Fargate クラスタ */
        this.fargateApp = new FargateAppConstruct(this, 'FargateApp', {
            vpc: props.vpc.vpc,
            privateSubnets: props.vpc.privateSubnets,
            publicSubnets: props.vpc.publicSubnets,
            ecsClusterName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecs',
                use: `cluster`,
                ...props.namingStackProps
            }),
            cdkAutoRemove: /^ctc[0-9]$/.test(props.namingStackProps.envKey)
        });

        /** lems サービス */
        this.fargateAppLems = this.fargateApp.createAppService('LemsService', {
            ecrRepository: props.lemsProps.ecrRepository,
            dockerTag: props.lemsProps.dockerTag,
            containerDesiredCount: props.lemsProps.containerDesiredCount || 0,
            containerPort: lemsContainerPort,
            cpu: props.lemsProps.cpu,
            memoryLimitMiB: props.lemsProps.memoryLimitMiB,
            healthCheckPath: lemsHealthCheckPath,
            environment: {
                NODE_ENV: props.namingStackProps.envKey,
                REGION: props.env?.region || '',
                MYSQL_SECRET_NAME: props.dbSecret?.secretName || '',
                JWT_SECRET_KEY: 'secretKey',
                JWT_EXPIRES_IN: '10h',
                MASTER_FILES_BUCKET_NAME: props.masterFilesBucket?.bucketName || '',
                UPLOADED_CHECKUP_RESULT_FILES_BUCKET_NAME: props.uploadCheckupResultFilesBucket?.bucketName || '',
                EXECUTED_CHECKUP_RESULT_FILES_BUCKET_NAME: props.executedCheckupResultFilesBucket?.bucketName || '',
            },
            secretEnv: props.dbSecret !== undefined ? {
                'MYSQL_DATABASE': ecs.Secret.fromSecretsManager(props.dbSecret, 'dbname'),
                'MYSQL_USER': ecs.Secret.fromSecretsManager(props.dbSecret, 'username'),
                'MYSQL_HOST': ecs.Secret.fromSecretsManager(props.dbSecret, 'host'),
                'MYSQL_PORT': ecs.Secret.fromSecretsManager(props.dbSecret, 'port'),
                'MYSQL_PASSWORD': ecs.Secret.fromSecretsManager(props.dbSecret, 'password'),
            } : undefined,
            ecsLogsGroupName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'cwl',
                use: `lems`,
                ...props.namingStackProps
            }),
            ecsServiceName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecs-service',
                use: `lems`,
                ...props.namingStackProps
            }),
            ecsServiceSgName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'sg',
                use: `lems-ecs`,
                ...props.namingStackProps
            }),
            ecsTaskExecutionRoleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'role',
                use: `lems-ecste`,
                ...props.namingStackProps
            }),
            ecsTaskName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecs-task',
                use: `lems`,
                ...props.namingStackProps
            }),
            ecsTaskRoleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'role',
                use: `lems-ecst`,
                ...props.namingStackProps
            }),
        })
        // ターゲットグループ登録
        props.alb.addAlbTarget({
            port: this.fargateAppLems.containerPort,
            targets: [this.fargateAppLems.ecsService],
            accessPermissionHeader: props.cloudFrontAccessPermissionHeader,
            healthCheckPath: lemsHealthCheckPath,
        });
        // アラーム
        if (props.snsAlarmTopicArn) {
            const topic = sns.Topic.fromTopicArn(this, 'SnsTopic', props.snsAlarmTopicArn);
            this.fargateAppLems.addServiceCpuArarm('ServiceCpuAlarm', topic, 0.85,
                ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'alarm',
                    use: 'lems-service-cpu-utilization',
                    ...props.namingStackProps
                })
            );
            this.fargateAppLems.addServiceMemoryArarm('ServiceMemoryAlarm', topic, 0.85,
                ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'alarm',
                    use: 'lems-service-memory-utilization',
                    ...props.namingStackProps
                })
            );
            this.fargateAppLems.addRunningTaskCountArarm('RunningTaskCountArarm', topic, 1,
                ResourceNameBuilder.makeResourceNameStr({
                    serviceName: 'alarm',
                    use: 'lems-running-task-count',
                    ...props.namingStackProps
                })
            );
        }
        // ログバックアップ
        new LogsS3BackupConstruct(this, 'LemsLogBackup', {
            destinationBucket: cwlBackupS3.s3Bucket,
            sourceLogGroup: this.fargateAppLems.ecsLogsGroup,
            streamName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'stream',
                use: 'ecs-lems',
                ...props.namingStackProps
            }),
            deliveryStreamName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'deliveryStream',
                use: 'ecs-lems',
                ...props.namingStackProps
            })
        });
        /** CRCB バッチ */
        this.fargateAppCrcb = this.fargateApp.createPutS3TrigerBatch('CrcbBatch', {
            eventTrigerS3Bucket: props.uploadCheckupResultFilesBucket,
            ecrRepository: props.crcbProps.ecrRepository,
            cpu: props.crcbProps.cpu,
            memoryLimitMiB: props.crcbProps.memoryLimitMiB,
            dockerTag: props.crcbProps.dockerTag,
            eventDescription: 'Start fargate task when upload convertedCheckupResult.',
            eventsRuleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'events',
                use: `crcb`,
                ...props.namingStackProps
            }),
            ecsLogsGroupName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'cwl',
                use: `crcb`,
                ...props.namingStackProps
            }),
            ecsTaskSgName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'sg',
                use: `crcb`,
                ...props.namingStackProps
            }),
            ecsTaskExecutionRoleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'role',
                use: `crcb-te`,
                ...props.namingStackProps
            }),
            ecsTaskRoleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'role',
                use: `crcb-t`,
                ...props.namingStackProps
            }),
            ecsTaskName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecs-task',
                use: `crcb`,
                ...props.namingStackProps
            }),
            environment: {
                NODE_ENV: props.namingStackProps.envKey,
                REGION: props.env?.region || '',
                MYSQL_SECRET_NAME: props.dbSecret?.secretName || '',
                JWT_SECRET_KEY: 'secretKey',
                JWT_EXPIRES_IN: '10h',
                UPLOADED_CHECKUP_RESULT_FILES_BUCKET_NAME: props.uploadCheckupResultFilesBucket?.bucketName || '',
                EXECUTED_CHECKUP_RESULT_FILES_BUCKET_NAME: props.executedCheckupResultFilesBucket?.bucketName || '',
                APP_API_JWT: 'Requieres Bearer Token.'
            },
            secretEnv: props.dbSecret !== undefined ? {
                'MYSQL_DATABASE': ecs.Secret.fromSecretsManager(props.dbSecret, 'dbname'),
                'MYSQL_USER': ecs.Secret.fromSecretsManager(props.dbSecret, 'username'),
                'MYSQL_HOST': ecs.Secret.fromSecretsManager(props.dbSecret, 'host'),
                'MYSQL_PORT': ecs.Secret.fromSecretsManager(props.dbSecret, 'port'),
                'MYSQL_PASSWORD': ecs.Secret.fromSecretsManager(props.dbSecret, 'password'),
            } : undefined,
        })
        // ログバックアップ
        new LogsS3BackupConstruct(this, 'CrcbLogBackup', {
            destinationBucket: cwlBackupS3.s3Bucket,
            sourceLogGroup: this.fargateAppCrcb.ecsLogsGroup,
            streamName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'stream',
                use: 'ecs-crcb',
                ...props.namingStackProps
            }),
            deliveryStreamName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'deliveryStream',
                use: 'ecs-crcb',
                ...props.namingStackProps
            })
        });
        /** MUBバッチ */
        this.fargateAppMub = this.fargateApp.createPutS3TrigerBatch('MubBatch', {
            eventTrigerS3Bucket: props.masterFilesBucket,
            ecrRepository: props.mubProps.ecrRepository,
            cpu: props.mubProps.cpu,
            memoryLimitMiB: props.mubProps.memoryLimitMiB,
            dockerTag: props.mubProps.dockerTag,
            eventDescription: 'Start fargate task when upload a masterfile.',
            environment: {
                NODE_ENV: props.namingStackProps.envKey,
                REGION: props.env?.region || '',
                MYSQL_SECRET_NAME: props.dbSecret?.secretName || '',
                JWT_SECRET_KEY: 'secretKey',
                JWT_EXPIRES_IN: '10h',
                MASTER_FILES_BUCKET_NAME: props.masterFilesBucket?.bucketName || '',
            },
            secretEnv: props.dbSecret !== undefined ? {
                'MYSQL_DATABASE': ecs.Secret.fromSecretsManager(props.dbSecret, 'dbname'),
                'MYSQL_USER': ecs.Secret.fromSecretsManager(props.dbSecret, 'username'),
                'MYSQL_HOST': ecs.Secret.fromSecretsManager(props.dbSecret, 'host'),
                'MYSQL_PORT': ecs.Secret.fromSecretsManager(props.dbSecret, 'port'),
                'MYSQL_PASSWORD': ecs.Secret.fromSecretsManager(props.dbSecret, 'password'),
            } : undefined,
            eventsRuleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'events',
                use: `mub`,
                ...props.namingStackProps
            }),
            ecsLogsGroupName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'cwl',
                use: `mub`,
                ...props.namingStackProps
            }),
            ecsTaskSgName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'sg',
                use: `mub`,
                ...props.namingStackProps
            }),
            ecsTaskExecutionRoleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'role',
                use: `mub-te`,
                ...props.namingStackProps
            }),
            ecsTaskRoleName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'role',
                use: `mub-t`,
                ...props.namingStackProps
            }),
            ecsTaskName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'ecs-task',
                use: `mub`,
                ...props.namingStackProps
            }),
        });
        // ログバックアップ
        new LogsS3BackupConstruct(this, 'MubLogBackup', {
            destinationBucket: cwlBackupS3.s3Bucket,
            sourceLogGroup: this.fargateAppMub.ecsLogsGroup,
            streamName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'stream',
                use: 'ecs-mub',
                ...props.namingStackProps
            }),
            deliveryStreamName: ResourceNameBuilder.makeResourceNameStr({
                serviceName: 'deliveryStream',
                use: 'ecs-mub',
                ...props.namingStackProps
            })
        });
    }
}