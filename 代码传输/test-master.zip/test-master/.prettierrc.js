
rts = {
	  printWidth: 120,
	  tabWidth: 2,
	  semi: true,
	  endOfLine: "crlf",
	  trailingComma: "all",
	  parser: "typescript",
	  quoteProps: "consistent",
};
